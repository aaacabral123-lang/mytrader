# MyTrader — iPhone paper trading demo

A static, mobile-friendly **educational simulation**. The UI is in English and uses fixed invented sample prices. It does **not** connect to Alpaca, fetch real-time market data, generate AI signals, send push notifications, or place any broker orders.

## Run

Open `index.html` in a browser, or deploy the contents of this folder as a static website. State is stored locally in that browser using `localStorage`. The demo starts with $100 fictional cash.

## Publish free with GitHub Pages

1. Create a GitHub repository named `mytrader` (public if using the standard free GitHub Pages setup).
2. Upload `index.html`, `manifest.webmanifest`, and `README.md` to the repository root.
3. In the repository, open **Settings → Pages**, select **Deploy from a branch**, branch **main**, folder **/(root)**, and save.
4. Once published, open `https://YOUR_USERNAME.github.io/mytrader/` on your iPhone in Safari. Choose **Share → Add to Home Screen**.

If Pages is unavailable for your account/repository, a static host such as Cloudflare Pages can serve the same files.

## Important limitations

- Every displayed price is a fixed invented demo number, not a real stock quote.
- The $0.50 displayed planned risk is illustrative only, not an enforced stop or loss cap.
- Approve Buy/Sell changes local demo state only; there is no Alpaca integration.
- No AI signal engine, automated strategy, or iPhone notifications exist yet.
- Do not paste Alpaca API keys into this website or a public GitHub repository. Future integration needs a secure server-side backend and explicit per-order approvals.
